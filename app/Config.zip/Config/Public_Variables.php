<?php

class Public_Variables
{
    public $BASE_URL = '/abfphotolab/';
    public $ASSETS_URL = '/abfphotolab/assets/';

    public $SETTING = [
        "wa_float" => "6285210692884",
        "ongkir_toko" => "10000",
        "notif_group" => "120363210714113378@g.us", // developer
        // "notif_group" => "6281268098300-1581749587@g.us", // real
        "mode" => 0 // 0 dev, 1 pro
    ];

    public $REKENING = [
        0 => [
            "bank" => "BCA",
            "nama" => "ABIDIN",
            "no" => 8462154222
        ]
    ];

    public $CS = [
        0 => [
            "no" => "081268098300",
            "nama" => "Luhur CS"
        ]
    ];

    // public $KURIR = ['jne', 'pos', 'tiki', 'rpx', 'pandu', 'wahana', 'sicepat', 'jnt', 'pahala', 'sap', 'jet', 'indah', 'dse', 'slis', 'first', 'ncs', 'star', 'ninja', 'lion', 'idl', 'rex', 'ide', 'sentral', 'anteraja', 'jtl'];
    public $KURIR = ['jne', 'pos', 'tiki', 'wahana', 'sicepat', 'jnt', 'indah', 'lion', 'anteraja'];
}
