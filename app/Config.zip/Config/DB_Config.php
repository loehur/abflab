<?php

class DB_Config
{
    public $db_host = 'localhost';
    public $controller = 'Home';

    public $dbm = array(
        0 => array(
            "db" => "abfphotolab",
            "user" => "root",
            "pass" => ""
        ),
    );
}
